<?php
/**
 * Database Configuration
 * Fishing Log Application
 */

// Database credentials
define('DB_HOST', 'sql304.infinityfree.com');
define('DB_USER', 'userif0_41317257');
define('DB_PASS', 'MVTrL6n7J1o0');
define('DB_NAME', 'fishinglog');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die(json_encode([
        'success' => false,
        'message' => 'Koneksi database gagal: ' . $conn->connect_error
    ]));
}

// Set charset to UTF-8
$conn->set_charset("utf8");

// Set timezone
date_default_timezone_set('Asia/Jakarta');

/**
 * CORS Configuration
 * Restrict to localhost for security
 */
function setCorsHeaders() {
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    // Allow only localhost origins
    if (strpos($origin, 'localhost') !== false || strpos($origin, '127.0.0.1') !== false) {
        header('Access-Control-Allow-Origin: ' . $origin);
    }
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
}
?>
